using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System;
//using SeleniumExtras.WaitHelpers;

namespace My_Nunit
{
    [TestFixture]
    public class NunitTest
    {
        //int i;
         IWebDriver driver;

        [SetUp]
        public void Initialize()
        {
            driver = new ChromeDriver();
            Thread.Sleep(2000);
            driver.Manage().Window.Maximize();
            driver.Url = "https://docs.google.com/forms/d/e/1FAIpQLSfheX-lBN1r477rwQ1tigtXmYgpNScgZzPV8Y9Nqe-2EHMZew/viewform";
            Thread.Sleep(2000);
            var Uname = driver.FindElement(By.Id("identifierId"));
            Uname.SendKeys("ritesh@atharvasystem.com");
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//input[@type='password']")).SendKeys("ritz@6011");
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(3000);
        }
        [Test]
        public void SprintReview()
        {

            driver.FindElement(By.XPath("//span[contains(text(), 'Sprint')]//ancestor::div[@class='bzfPab wFGF8']//descendant::div[@class='vd3tt']")).Click();            
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(3000);
            IWebElement cSprint = driver.FindElement(By.XPath("//span[contains(text(), 'Choose your Sprint')]//ancestor::div[@class='Qr7Oae']//descendant::div[@class='MocG8c HZ3kWc mhLiyf LMgvRb KKjvXb DEh1R']"));
            cSprint.Click();
            Thread.Sleep(2000);
            //Sprint Select
            IWebElement sSprint = driver.FindElement(By.XPath("//span[contains(text(), 'Sprint K') and parent::*[parent::div[not(@aria-hidden)]]]"));
            Thread.Sleep(2000);
            sSprint.Click();
            Thread.Sleep(2000);
            //Sprint Start Date
            IWebElement sDate = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'Sprint starts from')]]//child::div[@class='aXBtI Wic03c']//child::input[@type='date']"));
            sDate.SendKeys("05042022");
            Thread.Sleep(4000);
            //Sprint End Date
            IWebElement sendDate = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'Sprint Ends on')]]//child::div[@class='aXBtI Wic03c']//child::input[@type='date']"));
            sendDate.SendKeys("19042022");
            Thread.Sleep(3000);
        }
        [Test]
        public void DailyStatus()
        {
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Daily Status')]")).Click();
            Thread.Sleep(5000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(5000);
        }
        [Test]
        public void StoryReview()
        {
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Story')]")).Click();
            Thread.Sleep(5000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(5000);
        }
        [Test]
        public void DailyMeetings()
        {
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Daily Mee')]")).Click();
            Thread.Sleep(5000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(5000);
        }
        [TearDown]
        public void EndTest()
        {
            //driver.Close();
        }
    }
}