using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System;
//using SeleniumExtras.WaitHelpers;

namespace My_Nunit
{
    [TestFixture]
    public class NunitTest
    {
        //int i;
         public IWebDriver driver;

        [SetUp]
        public void Initialize()
        {
            driver = new ChromeDriver();
            Thread.Sleep(2000);
            driver.Manage().Window.Maximize();
            driver.Url = "https://docs.google.com/forms/d/e/1FAIpQLSfheX-lBN1r477rwQ1tigtXmYgpNScgZzPV8Y9Nqe-2EHMZew/viewform";
            Thread.Sleep(2000);
            var Uname = driver.FindElement(By.Id("identifierId"));
            Uname.SendKeys("ritesh@atharvasystem.com");
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//input[@type='password']")).SendKeys("ritz@6011");
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(3000);
        }
        [Test]
        public void SprintReview()
        {

            driver.FindElement(By.XPath("//span[contains(text(), 'Sprint')]//ancestor::div[@class='bzfPab wFGF8']//descendant::div[@class='vd3tt']")).Click();            
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(3000);
            IWebElement cSprint = driver.FindElement(By.XPath("//span[contains(text(), 'Choose your Sprint')]//ancestor::div[@class='Qr7Oae']//descendant::div[@class='MocG8c HZ3kWc mhLiyf LMgvRb KKjvXb DEh1R']"));
            Thread.Sleep(2000);
            cSprint.Click();
            Thread.Sleep(2000);
            //Sprint Select
            IWebElement sSprint = driver.FindElement(By.XPath("//span[contains(text(), 'Sprint K') and parent::*[parent::div[not(@aria-hidden)]]]"));
            Thread.Sleep(2000);
            sSprint.Click();
            Thread.Sleep(2000);
            //Sprint Start Date
            IWebElement sDate = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'Sprint starts from')]]//child::div[@class='aXBtI Wic03c']//child::input[@type='date']"));
            sDate.SendKeys("05042022");
            Thread.Sleep(3000);
            //Sprint End Date
            IWebElement sendDate = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'Sprint Ends on')]]//child::div[@class='aXBtI Wic03c']//child::input[@type='date']"));
            sendDate.SendKeys("19042022");
            Thread.Sleep(3000);
            IWebElement tHours = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'Total Available Hours for Sprint work (Formula : No of days *7hours) ')]]//child::input[@type='text']"));
            Thread.Sleep(2000);
            tHours.SendKeys("30h");
            Thread.Sleep(1200);
            //Total Allocated Hours
            IWebElement allowHours = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'Total Allocated hours of work (Note: Write down count in numeric eg. 35)')]]//child::input[@jsname='YPqjbf']"));
            Thread.Sleep(2000);
            allowHours.SendKeys("30h");
            Thread.Sleep(2000);
            //Regression starts from Date
            IWebElement rstartDate = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'Regression starts from')]]//child::input[@class='whsOnd zHQkBf']"));
            Thread.Sleep(2000);
            rstartDate.SendKeys("23042022");
            Thread.Sleep(2000);
            //Regression End Date
            IWebElement rendDate = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'Regression Ends on')]]//child::input[@type='date']"));
            Thread.Sleep(2000);
            rendDate.SendKeys("25042022");
            Thread.Sleep(2000);
            //Product Regression hours
            IWebElement prHours = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'Product Regression hours')]]//child::input[@type='text']"));
            Thread.Sleep(2000);
            prHours.SendKeys("20h");
            Thread.Sleep(1000);
            //Sprint Regression hours:
            IWebElement srHours = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'Sprint Regression hours')]]//child::input[@class='whsOnd zHQkBf']"));
            Thread.Sleep(2000);
            srHours.SendKeys("10h");
            Thread.Sleep(2000);
            //Enter the leave hours during sprint days:
            IWebElement leaveHours = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'Enter the leave hours during sprint days')]]//child::input[@jsname='YPqjbf']"));
            Thread.Sleep(2000);
            leaveHours.SendKeys("8h");
            Thread.Sleep(2000);
            //How many stories of this sprint u got where You have doubt which needs to be solved before sprint starts? *
            IWebElement sDoubts = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'How many stories of this sprint u got')]]//child::div[@class='MocG8c HZ3kWc mhLiyf LMgvRb KKjvXb DEh1R']"));
            Thread.Sleep(2000);
            sDoubts.Click();
            Thread.Sleep(2000);
            IWebElement selectDoubt = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'How many stories of this sprint u got')]]//child::span[text ()= '2' and parent::*[parent::div[not(@aria-hidden)]]]"));
            Thread.Sleep(2000);
            selectDoubt.Click();
            Thread.Sleep(2000);
            //How many stories of this sprint for which you resolved your doubts *
            IWebElement resolvedDoubt = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'How many stories of this sprint for which you')]]//child::div[@class='MocG8c HZ3kWc mhLiyf LMgvRb KKjvXb DEh1R']"));
            Thread.Sleep(2000);
            resolvedDoubt.Click();
            Thread.Sleep(1000);
            IWebElement selectclearDoubt = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'How many stories of this sprint for which you')]]//child::span[text ()= '2' and parent::*[parent::div[not(@aria-hidden)]]]"));
            selectclearDoubt.Click();
            Thread.Sleep(1000);
            //How many stories of this sprint for which still needs to be clarified with help of any other team member
            IWebElement stillDoubt = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'How many stories of this sprint for which still')]]//child::div[@class='MocG8c HZ3kWc mhLiyf LMgvRb KKjvXb DEh1R']"));
            stillDoubt.Click();
            Thread.Sleep(1000);
            IWebElement selectsdobut = driver.FindElement(By.XPath("//div[@class='Qr7Oae'][.//span[contains(text(), 'How many stories of this sprint for which still')]]//child::span[text ()= '1' and parent::*[parent::div[not(@aria-hidden)]]]"));
            selectsdobut.Click();
            Thread.Sleep(1000);
            //Send me copy of my Responses
            IWebElement sendCopy = driver.FindElement(By.XPath("//div[@class='E7QdY espmsb']"));
            sendCopy.Click();
            Thread.Sleep(1000);
            //Submit Form
            IWebElement submitForm = driver.FindElement(By.XPath("//span[contains(text(), 'Submit')]"));
            submitForm.Click();
            Thread.Sleep(1000);
        }
        [Test]
        public void DailyStatus()
        {
            
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Daily Status')]")).Click();
            Thread.Sleep(5000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(5000);
        }
        [Test]
        public void StoryReview()
        {
/*            Story_Review obj = new Story_Review();
            obj.storyReview();*/
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Story')]")).Click();
            Thread.Sleep(5000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(3000);
            var rdate = driver.FindElement(By.XPath("//input[@type='date']"));
            rdate.SendKeys("25062022");
            Thread.Sleep(3000);
            IWebElement cSprint = driver.FindElement(By.XPath("//span[contains(text(), 'Choose your Sprint')]//ancestor::div[@class='Qr7Oae']//descendant::div[@class='MocG8c HZ3kWc mhLiyf LMgvRb DEh1R KKjvXb']"));
            Thread.Sleep(2000);
            cSprint.Click();
            Thread.Sleep(2000);
            //Sprint Select
            IWebElement sSprint = driver.FindElement(By.XPath("//span[contains(text(), 'POS') and parent::*[parent::div[not(@aria-hidden)]]]"));
            sSprint.Click();
            Thread.Sleep(2000);
            IWebElement type = driver.FindElement(By.XPath("//span[contains(text(), 'Manu')]"));
            type.Click();
            Thread.Sleep(2000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(3000);
        }
        [Test]
        public void DailyMeetings()
        {
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Daily Mee')]")).Click();
            Thread.Sleep(5000);
            driver.FindElement(By.XPath("//span[contains(text(), 'Next')]")).Click();
            Thread.Sleep(5000);
        }
        [TearDown]
        public void EndTest()
        {
            //driver.Close();
        }
    }
}